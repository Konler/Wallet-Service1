create function convert_to_varchar(i integer) returns character
    language sql
as
$$select *
 from (select case
when i = 0 then '0'
when i = 1 then '1'
when i = 2 then '2'
when i = 3 then '3'
when i = 4 then '4'
when i = 5 then '5'
when i = 6 then '6'
when i = 7 then '7'
when i = 8 then '8'
when i = 9 then '9'
end) alias$$;

alter function convert_to_varchar(integer) owner to postgres;

