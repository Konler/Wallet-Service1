create function create_random_code() returns character
    language sql
as
$$select *
 from ((select convert_to_varchar(cast((floor(random()*10)) as int)))
) alias$$;

alter function create_random_code() owner to postgres;

