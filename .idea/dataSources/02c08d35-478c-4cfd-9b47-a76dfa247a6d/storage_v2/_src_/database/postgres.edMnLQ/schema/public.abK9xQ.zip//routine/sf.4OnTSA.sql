create function sf(a integer) returns integer
    language sql
as
$$select *
 from (select case when a = 1 then 1 else sf(a - 1) + a end) alias$$;

alter function sf(integer) owner to postgres;

