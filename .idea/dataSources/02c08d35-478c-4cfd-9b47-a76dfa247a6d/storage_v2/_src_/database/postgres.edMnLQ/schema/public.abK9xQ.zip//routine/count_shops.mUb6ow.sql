create function count_shops(s character varying) returns integer
    language sql
as
$$SELECT COUNT(*) FROM shops WHERE title = s$$;

alter function count_shops(varchar) owner to postgres;

