create function create_code(i integer) returns character varying
    language sql
as
$$select *
 from ((select convert_to_varchar(cast((floor(random()*10)) as int)))
) alias$$;

alter function create_code(integer) owner to postgres;

