create function count_shops_by_title(s character varying) returns integer
    language sql
as
$$select count from titles where title = s$$;

alter function count_shops_by_title(varchar) owner to postgres;

