create function union_all_for_me(this_separation integer) returns integer
    language sql
as
$$select sum(amount) from (select amount from genome_alternative where separation = this_separation) as alias$$;

alter function union_all_for_me(integer) owner to postgres;

