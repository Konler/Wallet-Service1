create function create_unique_code(i integer) returns character varying
    language sql
as
$$select create_random_code() || create_random_code() || create_random_code() || convert_to_varchar_6(i)$$;

alter function create_unique_code(integer) owner to postgres;

