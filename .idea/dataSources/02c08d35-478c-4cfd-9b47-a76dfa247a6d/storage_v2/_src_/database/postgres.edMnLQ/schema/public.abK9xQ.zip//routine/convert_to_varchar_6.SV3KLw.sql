create function convert_to_varchar_6(i integer) returns character varying
    language sql
as
$$select * from (select convert_to_varchar(((i/100000)%10))
|| convert_to_varchar(((i/10000)%10))
|| convert_to_varchar(((i/1000)%10))
|| convert_to_varchar(((i/100)%10))
|| convert_to_varchar((i/10)%10)
|| convert_to_varchar(i%10)
)
alias$$;

alter function convert_to_varchar_6(integer) owner to postgres;

