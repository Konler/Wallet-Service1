create procedure procedure_name(a integer)
    language plpgsql
as
$$
begin
    select CASE WHEN a = 1 THEN 1
        ELSE procedure_name(a-1)*a end;
end;$$;

alter procedure procedure_name(integer) owner to postgres;

