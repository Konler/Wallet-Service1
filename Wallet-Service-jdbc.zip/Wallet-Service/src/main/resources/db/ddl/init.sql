INSERT INTO my_schema.players (login, balance, password) VALUES ('user1', 100.00, 12345);
INSERT INTO my_schema.players (login, balance, password) VALUES ('user2', 200.00, 54321);

INSERT INTO my_schema.players (login, balance, password) VALUES ('user1', 100.00, 12345);
INSERT INTO my_schema.players (login, balance, password) VALUES ('user2', 200.00, 54321);