package ru.ylab.task1.exception;

/**
 * The type Login exists exception.
 */
public class LoginExistsException extends Exception {


}
