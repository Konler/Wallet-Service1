package ru.ylab.task1.exception;

public class NotFoundException extends Exception {
}
