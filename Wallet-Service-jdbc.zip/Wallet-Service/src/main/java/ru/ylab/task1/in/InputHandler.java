package ru.ylab.task1.in;

/**
 * The interface Input handler.
 */
public interface InputHandler {

    String getUserInput();


    void close();

}
